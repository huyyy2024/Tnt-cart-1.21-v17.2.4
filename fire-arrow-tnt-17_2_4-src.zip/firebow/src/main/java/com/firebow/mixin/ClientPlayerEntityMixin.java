package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    /**
     * Phase 2 của 2-tick pattern:
     * beforeSync gọi TRƯỚC khi movement packet gửi đi.
     * RotationUtil.applyBeforeSync() đảm bảo rotation trong packet
     * khớp với hit vector của interactBlock tick sau.
     */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }
}
